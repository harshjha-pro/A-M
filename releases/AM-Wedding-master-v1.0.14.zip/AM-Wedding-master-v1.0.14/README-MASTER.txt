A&M Wedding Planner — master ZIP (version 1.0.14, after Session 13)
==================================================================

source/   The whole project: api/ (PHP), web/ (React), db/ (migrations, demo data, demo
          files), docs/ (CONTEXT, FEATURES, API, DATABASE, TESTING, DATA-SAFETY,
          IMPLEMENTATION, PWA, DESIGN, SESSION-LOG, openapi.yaml), tools/, scripts/,
          public_html/, tests, RELEASE-NOTES.md, TEST-REPORT.md, and .git (full history).
          Use it to continue in a new chat or to rebuild everything.

deploy/   Ready to upload to Hostinger (same as deploy-session13.zip):
            staging/  1-server.zip → 2-assets.zip → 3-shell.zip → version.json LAST
            live/     the same for the live site
            migrations/          SQL to run first, if any (NONE.txt = nothing)
            RELEASE-NOTES.md     upload steps and phone checks
            TEST-REPORT.md       test results

Not inside, on purpose:
  - .env files and any passwords or keys (make .env from source/.env.example on the server)
  - web/node_modules and api/vendor (rebuild: cd web && npm ci ; cd api && composer install)
  - web/dist* build folders (rebuild: cd web && npm run build:staging / build:live)
